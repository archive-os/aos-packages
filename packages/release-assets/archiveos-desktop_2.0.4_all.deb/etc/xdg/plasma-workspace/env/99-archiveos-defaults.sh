export XDG_CONFIG_DIRS=/etc/xdg:/usr/share/archiveos-default-settings
