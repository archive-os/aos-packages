#!/usr/bin/env python3
"""User-session helper for Plasma 6.4 ArchiveOS theme wallpaper changes."""
import argparse
import fcntl
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

WALLPAPERS = {
    "org.archiveos.desktop": "/usr/share/wallpapers/ArchiveOS/ArchiveOS-on-the-Horizon.png",
    "org.archiveos-dark.desktop": "/usr/share/wallpapers/ArchiveOS/ArchiveOS-on-the-Horizon-Dark.png",
}


def selected_theme():
    result = subprocess.run(
        ["kreadconfig6", "--file", "kdeglobals", "--group", "KDE", "--key", "LookAndFeelPackage"],
        capture_output=True, text=True, timeout=5, check=True,
    )
    return result.stdout.strip()


def apply_wallpaper(theme, dry_run=False):
    image = WALLPAPERS.get(theme)
    if image is None:
        return True
    if not Path(image).is_file():
        print(f"ArchiveOS: duvar kâğıdı bulunamadı: {image}", file=sys.stderr, flush=True)
        return False
    if dry_run:
        print(f"{theme} -> {image}", flush=True)
        return True
    apply_splash(theme)
    result = subprocess.run(["plasma-apply-wallpaperimage", image],
                            capture_output=True, text=True, timeout=15)
    if result.returncode:
        print(f"ArchiveOS: wallpaper uygulaması başarısız: {result.stderr.strip()}",
              file=sys.stderr, flush=True)
        return False
    print(f"ArchiveOS: {theme} -> {image}", flush=True)
    return True


def apply_splash(theme):
    if theme not in WALLPAPERS:return
    for key,value in (('Theme','org.archiveos.desktop'),('Engine','KSplashQML')):
        subprocess.run(['kwriteconfig6','--file','ksplashrc','--group','KSplash','--key',key,value],
                       check=True,timeout=5)


class ThemeWatcher:
    """Observe the first successful theme read without modifying the desktop."""
    def __init__(self):
        self.initialized = False
        self.applied_theme = None

    def observe(self, theme):
        if not self.initialized:
            # Plasma already restores the user's chosen wallpaper at login.
            # A new helper process must not mistake login for a theme change.
            self.applied_theme = theme
            self.initialized = True
            return True
        if theme == self.applied_theme:
            return True
        if apply_wallpaper(theme):
            self.applied_theme = theme
            return True
        return False


def fingerprint(paths):
    values = []
    for path in paths:
        try:
            stat = path.stat()
            values.append((stat.st_ino, stat.st_mtime_ns, stat.st_size))
        except FileNotFoundError:
            values.append(None)
    return tuple(values)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--once", action="store_true", help="Seçili temanın duvar kâğıdını bir kez uygula")
    parser.add_argument("--dry-run", action="store_true", help="Yalnız seçili tema ve görseli göster")
    args = parser.parse_args()
    for command in ("kreadconfig6", "kwriteconfig6", "plasma-apply-wallpaperimage"):
        if not shutil.which(command):
            raise RuntimeError(f"Komut eksik: {command}")
    if args.once or args.dry_run:
        return 0 if apply_wallpaper(selected_theme(), args.dry_run) else 1
    runtime = os.environ.get("XDG_RUNTIME_DIR")
    if not runtime:
        raise RuntimeError("KDE kullanıcı oturumunda çalıştırılmalı (XDG_RUNTIME_DIR eksik).")
    lock = open(Path(runtime) / "archiveos-theme-wallpaper.lock", "a")
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        return 0
    config = Path(os.environ.get("XDG_CONFIG_HOME", str(Path.home() / ".config")))
    config_dirs = os.environ.get("XDG_CONFIG_DIRS", "/etc/xdg").split(":")
    paths = [config / "kdeglobals", config / "kdedefaults/kdeglobals"]
    paths.extend(Path(folder) / "kdeglobals" for folder in config_dirs if folder)
    previous_files = None
    watcher = ThemeWatcher()
    next_retry = 0.0
    while True:
        files = fingerprint(paths)
        if files != previous_files or next_retry and time.monotonic() >= next_retry:
            time.sleep(0.5)
            previous_files = fingerprint(paths)
            try:
                theme = selected_theme()
                if watcher.observe(theme):
                    next_retry = 0.0
                else:
                    next_retry = time.monotonic() + 10
            except (OSError, subprocess.SubprocessError) as error:
                print(f"ArchiveOS: {error}", file=sys.stderr, flush=True)
                next_retry = time.monotonic() + 10
        time.sleep(1)


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, RuntimeError, subprocess.SubprocessError) as error:
        print(f"HATA: {error}", file=sys.stderr)
        sys.exit(1)
