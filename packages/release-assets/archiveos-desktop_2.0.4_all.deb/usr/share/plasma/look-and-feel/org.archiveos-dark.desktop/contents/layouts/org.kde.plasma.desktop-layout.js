loadTemplate("org.archiveos.defaultPanel")

var desktopsArray = desktopsForActivity(currentActivity());
for (var j = 0; j < desktopsArray.length; j++) {
    desktopsArray[j].wallpaperPlugin = 'org.kde.image';
    desktopsArray[j].currentConfigGroup = Array("Wallpaper", "org.kde.image", "General");
    desktopsArray[j].writeConfig("Image", "/usr/share/wallpapers/ArchiveOS/ArchiveOS-on-the-Horizon-Dark.png");
}
